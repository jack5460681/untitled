import unittest
import os
from appium import webdriver
import time
import HTMLTestRunner


PATH = lambda p: os.path.abspath(
        os.path.join(os.path.dirname(__file__), p)
)

class login2(unittest.TestCase):
    def setUp(self):
        package = 'com.aazen.companion'
        activity = 'com.aazen.companion.main.LauncherActivity'
        # 以下两种定义 desired_caps 的方式都可以使用
        desired_caps = {
            'platformName' : 'Android',
            'platformVersion' : '6.0.1',
            'deviceName' : 'efe5d82d',
            'app' : PATH('../img/AazenWearCompanion.apk'),
            'appPackage' : package,
            'appActivity' : activity,
            'unicodeKeyboard' : 'True',
            'resetKeyboard' : 'True',
            'fastReset' : 'T',
        }
        self.driver = webdriver.Remote('http://127.0.0.1:4723/wd/hub', desired_caps)

    def tearDown(self):
        self.driver.quit()

    def test_dmo(self):
        time.sleep(6)
        ac2 = self.driver.current_activity
        print(ac2)

        # L = ['a', 'b', 'c']
        # for循环
        # for x in L:
        #     print('hello, %s' % x)
        # while循环
        # it1 = len(L)
        # n = 0
        # while n < it1:
        #     print('hello,%s' % L[n])
        #     n = n + 1
        # print(n)


if __name__ == '__main__':
    suite = unittest.TestLoader().loadTestsFromTestCase(login2)
    unittest.TextTestRunner(verbosity=2).run(suite)