# coding=utf-8
__author__ = 'JJLanMo'


import unittest
import os
from appium import webdriver
import time
import HTMLTestRunner


PATH = lambda p: os.path.abspath(
        os.path.join(os.path.dirname(__file__), p)
)

class login1(unittest.TestCase):
    def setUp(self):
        package = 'com.aazen.companion'
        activity = 'com.aazen.companion.main.LauncherActivity'
        # 以下两种定义 desired_caps 的方式都可以使用
        desired_caps = {
            'platformName' : 'Android',
            'platformVersion' : '6.0.1',
            'deviceName' : 'efe5d82d',
            'app' : PATH('../img/AazenWearCompanion.apk'),
            'appPackage' : package,
            'appActivity' : activity,
            'unicodeKeyboard' : 'True',
            'resetKeyboard' : 'True',
            'fastReset' : 'T',
        }
        # desired_caps['platformName'] = 'Android'
        # desired_caps['platformVersion'] = '6.0.1'
        # desired_caps['deviceName'] = 'efe5d82d '
        # desired_caps['app'] = PATH(
        #     '../img/AazenWearCompanion.apk'
        # )
        # desired_caps['appPackage'] = package
        # desired_caps['appActivity'] = activity
        # desired_caps['unicodeKeyboard'] = 'True'
        # desired_caps['resetKeyboard'] = 'True'
        # desired_caps['fastReset'] = 'false'

        self.driver = webdriver.Remote('http://127.0.0.1:4723/wd/hub', desired_caps)

    def tearDown(self):
        self.driver.quit()

    def test_dl(self):
        # 截图
        now = time.strftime("%Y_%m_%d_%H_%M_%S", time.localtime(time.time()))

        # 等待3s
        time.sleep(3)
        count = 1
        self.driver.save_screenshot('../img1/' + now + 'count +=1' + '.png')
        # activity .account.ActivityLogin
        c1 = '.account.ActivityLogin'
        c2 = self.driver.current_activity
        while c1 != c2 and count < 8:
            if self.driver.find_element_by_id('com.android.packageinstaller:id/permission_deny_button'):
                self.driver.find_element_by_id('com.android.packageinstaller:id/permission_allow_button').click()
            else:
                break
            count += 1
            # self.driver.current_activity('.account.ActivityLogin')

        # 点击登录按钮
        time.sleep(2)
        b1 = self.driver.find_element_by_id('com.aazen.companion:id/user_login')
        b1.click()
        time.sleep(1)
        # 输入帐号信息
        zh = self.driver.find_element_by_id('com.aazen.companion:id/user_mobile')
        zh.send_keys('13564733570')
        mm = self.driver.find_element_by_id('com.aazen.companion:id/user_password')
        mm.send_keys('123456')
        self.driver.save_screenshot('../img1/' + now + '.png')
        self.assertEqual(zh.text,'13564733570','帐号错误！')
        time.sleep(2)
        # 点击登录按钮
        b1.click()
        # activity account.ActivityFirstStart
        time.sleep(2)
        c4 = self.driver.current_activity
        c3 = '.account.ActivityFirstStart'
        if c4 == c3:
            self.driver.save_screenshot('../img1/' + now + '.png')
            print('Pass')
        else:
            self.driver.save_screenshot('../img1/' + now + '.png')
            print('校验失败！')
        self.driver.find_element_by_id('com.aazen.companion:id/login_out').click()

if __name__ == '__main__':
    suite = unittest.TestLoader().loadTestsFromTestCase(login1)
    unittest.TextTestRunner(verbosity=2).run(suite)
    # #容器
    # testreport = unittest.TestSuite()
    # testreport.addTest(login1('test_dl'))
    #
    # # 获取当前时间
    # now = time.strftime("%Y_%m_%d_%H_%M_%S", time.localtime(time.time()))
    #
    # # 打开一个文件，将result写入此file中
    # fp = open('D:\\log\\' + "Result" + now + ".html",'wb')
    # runner = HTMLTestRunner.HTMLTestRunner(stream=fp, title='Test result', description=u'Result:')
    # runner.run(testreport)
    # fp.close()
    #

